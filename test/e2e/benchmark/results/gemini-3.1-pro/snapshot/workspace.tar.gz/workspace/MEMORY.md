# Memory

## User Preferences
- **Role:** GEO Lead at Xianke (闲氪). Focuses on "Generative Engine Optimization" to make partner stores visible in AI models.
- **Approval Flow:** All external content publishing requires approval. Major strategic direction adjustments require confirmation.
- **Bot Persona Requirement:** Wants a customer-facing 24h store consultation bot with a friendly, lively tone (contrast with my own management-focused tone).

## Project Details
- **Xianke GEO Strategy:** Aiming to become the "Trusted Spatial Data Provider" for AI (可信空间数据提供商), moving away from traditional SEO trickery.
- **Partner Stores:** 5 current stores (3 in Changsha: 麻将, 茶室, KTV; 2 in Wuhan: 茶空间, KTV).
- **Content Pipeline:** `~/.aida/mock-publish-tmp/` (drafts) -> require approval -> `~/.aida/mock-publish/` (published).