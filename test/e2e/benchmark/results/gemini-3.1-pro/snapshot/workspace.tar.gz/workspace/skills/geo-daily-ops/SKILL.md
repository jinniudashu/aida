---
name: geo-daily-ops
description: Execute daily GEO monitoring, formulate 'One Model, One Strategy', generate drafts, and trigger publishing approval.
---
# 闲氪 GEO 每日自动化运营闭环 (GEO Daily Operations)

当定时任务或主动触发时执行此技能。核心目标是持续监控并优化闲氪旗下自助空间（如茶室、棋牌室、KTV）在主流大模型中的能见度和回答准确性。

## 执行步骤：

### 1. 监测与探查 (Monitor)
- 使用 `bps_query_entities` 筛选 `entityType=store`，获取全部营业门店列表。
- **(模拟)** 分别针对豆包、千问、元宝三大模型，构造用户提问（如：“武汉楚河汉街有什么安静办公的茶室推荐？”、“长沙五一广场附近的24小时KTV”）。
- **(模拟)** 收集并记录各模型对该门店的曝光排位与特征抓取准确度（是否包含核心特征如“湖景包间”、“步行街核心”等）。

### 2. 分析与“一模一策”策略 (Analyze & Strategy)
- 依据探测结果进行诊断，生成对应的优化策略：
  - **豆包偏好**：更侧重结构化事实与价格清晰度。
  - **千问偏好**：更注重长尾逻辑推理与地理位置关联。
  - **元宝偏好**：更喜欢生活方式场景、社交打卡类口语化文案。
- 结合业务资料 `~/.aida/context/闲氪GEO心智战略.md` 中的“可信履约”原则，确保补充信息真实有效。

### 3. 生成专属内容草稿 (Draft Content)
- 针对每家门店、每个大模型，分别生成一篇富含该店核心要素的优化文案。
- 文案必须基于门店实际数据（营业时间、容量、价格、特色），绝不捏造。

### 4. 写入草稿区 (Write to Temp)
- 使用 `write` 工具，将各个模型的草稿保存至：
  - `~/.aida/mock-publish-tmp/doubao/{storeId}.md`
  - `~/.aida/mock-publish-tmp/qianwen/{storeId}.md`
  - `~/.aida/mock-publish-tmp/yuanbao/{storeId}.md`

### 5. 触发发布审批 (Request Approval)
- 依次调用 `bps_update_entity` 工具创建或更新对应的 `geo-content` 实体，必须包含字段：
  - `entityId`: `{storeId}-{platform}-daily`
  - `entityType`: `geo-content`
  - `publishReady`: `1` (或 true，触发治理层拦截)
  - `contentPath`: 对应的草稿文件路径
- 收集系统返回的 Approval ID。

### 6. 生成每日运营小结 (Report)
- 将今日监测状况、采取的一模一策优化方案，以及提交审批的文档清单，汇总成一份清晰简练的运营小结，向负责人（用户）汇报，并附上 Dashboard 审批指引。

## Governance

This Skill operates under the following project governance constraints.
All write operations (`bps_update_entity`, `bps_create_task`, etc.) are automatically checked.
**Always create/update an entity via `bps_update_entity` before writing output files** — this triggers governance review.

- **Publishing content requires human approval** [HIGH]: Content publish requires approval: {entityId} (action: REQUIRE_APPROVAL)
- **Cannot archive content entities** [CRITICAL]: Cannot archive content: {entityId} (action: BLOCK)
- **Strategy changes require human approval** [HIGH]: Strategy change requires approval (action: REQUIRE_APPROVAL)