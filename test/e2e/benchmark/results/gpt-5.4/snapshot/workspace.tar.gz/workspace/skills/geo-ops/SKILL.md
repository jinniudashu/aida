---
name: geo-ops
description: Run Xianke GEO daily operations for store visibility monitoring, per-model strategy, draft generation, approval-first publishing, and reporting.
---
# GEO Operations

Operate Xianke's GEO system for partner stores using simulated or real model observations.

## Step 1: Read the operating context
- Read relevant business context from `~/.aida/context/` when strategy context is needed.
- Query store entities via `bps_query_entities(entityType="store")`.
- If reviewing a single store, fetch it with `bps_get_entity`.

## Step 2: Create or update the GEO strategy entity
- Use `bps_update_entity` on the relevant `geo-strategy` entity first.
- Store: target model, target mindshare, trigger scenarios, avoid scenarios, priority fields, expression style, strategic impact.
- If the change is major, set `strategicImpact: high` and `approvalStatus: pending`.

## Step 3: Record observations
- Use `bps_update_entity` to create/update `geo-observation` entities for each store × model × date.
- Record query template, simulated result, visibility score, accuracy score, scenario fit score, fulfillment readiness score, overall GEO score, and issues.

## Step 4: Generate approval-first content
- Before writing any outward-facing artifact, use `bps_update_entity` to create/update a `geo-content` entity with `approvalRequired: true`, `approvalStatus: pending`, `publishReady: false`, and the intended draft file path.
- Then write the draft file into `~/.aida/mock-publish-tmp/` only.
- Never write directly to `~/.aida/mock-publish/`.

## Step 5: Prepare reports
- Use `bps_update_entity` for `geo-report` entities first.
- Then write daily or weekly report drafts into `~/.aida/mock-publish-tmp/georeports/`.
- Include summary, model deltas, store deltas, draft queue, and next actions.

## Step 6: Approval and publishing rule
- External content must wait for human approval.
- Strategy changes with `strategicImpact: high` must wait for human approval.
- After approval, update the entity status and only then move or publish the artifact.

## Outputs
- `geo-observation` entities
- `geo-strategy` entities
- `geo-content` entities
- `geo-report` entities
- Draft files under `~/.aida/mock-publish-tmp/`
