#!/bin/bash
# 闲氪门店咨询Bot启动脚本
# Usage: ./start-store-bot.sh [channel]

echo "🏠 启动闲氪小助手..."
echo ""

# 检查workspace
if [ ! -d "~/.openclaw/workspace-store-bot" ]; then
    echo "❌ 错误：找不到Bot workspace"
    exit 1
fi

# 显示配置
echo "📋 Bot配置信息："
echo "  名称：闲氪小助手"
echo "  语气：亲切活泼（宝子/姐妹）"
echo "  工具：门店查询 + TTS语音"
echo ""

# 启动提示
echo "✅ 启动完成！"
echo ""
echo "💬 你可以这样问我："
echo "  • 长沙五一广场附近有什么KTV？"
echo "  • 悠然茶室怎么预订？"
echo "  • 音乐盒KTV多少钱一小时？"
echo "  • 给我推荐一个安静喝茶的地方"
echo ""
echo "🎤 Bot回复示例："
echo "  \"宝子来啦！✨ 今天想约哪个店呀？\""
echo ""

# 实际启动命令由OpenClaw网关处理
# 通过 sessions_spawn 启动子Agent