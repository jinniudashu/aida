---
name: geo-reporting
description: 生成GEO每日运营小结和每周深度复盘报告
---
# GEO报告生成技能

## 每日运营小结

### 报告结构
1. **执行摘要**（3句话）
   - 今日整体能见度均值
   - 表现最佳/最差门店
   - 待处理审批事项数量

2. **能见度监测结果**
   - 5家门店×3个模型矩阵
   - 分数变化趋势（↑↓→）
   - 异常提醒（分数<50或下降>10）

3. **内容产出状态**
   - 已生成内容数量
   - 待审批内容列表
   - 已发布内容汇总

4. **明日计划**
   - 重点优化门店
   - 策略调整方向

### 输出路径
`~/.aida/geo-reports/daily/YYYY-MM-DD.md`

## 每周深度复盘

### 报告结构
1. **周度数据总览**
   - 7天能见度趋势图（文字描述）
   - 各模型表现对比
   - 门店排名变化

2. **一模一策效果分析**
   - 策略执行完成度
   - 高分门店成功经验
   - 低分门店问题诊断

3. **内容产出分析**
   - 内容类型分布
   - 审批通过率
   - 发布后效果追踪

4. **下周战略调整建议**
   - 资源重新分配建议
   - 新增/减少的优化方向
   - 重大决策待确认事项

### 输出路径
`~/.aida/geo-reports/weekly/YYYY-WXX.md`

## 执行任务（每日）
1. 汇总当日所有监测数据
2. 生成简洁执行摘要
3. 列出待审批事项
4. 输出markdown报告

## 执行任务（每周）
1. 汇总7天数据计算趋势
2. 分析策略执行效果
3. 提出下周调整建议
4. 标记需人工确认的战略事项

## Governance

This Skill operates under the following project governance constraints.
All write operations (`bps_update_entity`, `bps_create_task`, etc.) are automatically checked.
**Always create/update an entity via `bps_update_entity` before writing output files** — this triggers governance review.

- **Publishing content requires human approval** [HIGH]: Content publish requires approval: {entityId} (action: REQUIRE_APPROVAL)
- **Cannot archive content entities** [CRITICAL]: Cannot archive content: {entityId} (action: BLOCK)
- **Strategy changes require human approval** [HIGH]: Strategy change requires approval (action: REQUIRE_APPROVAL)