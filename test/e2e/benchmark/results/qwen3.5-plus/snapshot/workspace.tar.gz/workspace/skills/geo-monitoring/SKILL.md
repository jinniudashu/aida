---
name: geo-monitoring
description: 每日监测门店在主流AI（豆包、千问、元宝）中的能见度，测试阶段使用模拟数据
---
# GEO每日监测技能

## 目标
监测5家合作门店在豆包、千问、元宝三大AI模型中的能见度表现。

## 测试阶段
使用模拟数据生成逻辑合理的能见度分数。

## 监测维度
1. **品牌提及率**：门店名称被AI提及的频率
2. **推荐排序**：在相关查询中的推荐位次
3. **信息准确度**：AI回答中门店信息的准确性
4. **场景覆盖度**：覆盖的用户查询场景数量

## 门店列表
- 长沙：棋乐无穷-岳麓山店、悠然茶室-芙蓉广场店、声临其境KTV-五一广场店
- 武汉：静享茶空间-楚河汉街店、音乐盒KTV-江汉路店

## 模拟数据生成逻辑
每家门店对每个AI模型生成0-100的能见度分数，基于：
- 门店类型热门度（KTV>茶室>棋牌）
- 商圈热度（五一广场>江汉路>楚河汉街>芙蓉广场>岳麓山）
- 随机波动±15分

## 输出格式
```json
{
  "date": "2026-03-10",
  "stores": [
    {
      "storeId": "store-cs-ktv-01",
      "name": "声临其境KTV-五一广场店",
      "visibility": {
        "doubao": 78,
        "qianwen": 65,
        "yuanbao": 72
      },
      "trends": "+5% vs 昨日"
    }
  ]
}
```

## 执行任务
1. 为每家门店生成当日能见度数据
2. 对比前一日数据计算趋势
3. 识别表现异常（分数<50或下降>10分）
4. 生成监测报告摘要

## Governance

This Skill operates under the following project governance constraints.
All write operations (`bps_update_entity`, `bps_create_task`, etc.) are automatically checked.
**Always create/update an entity via `bps_update_entity` before writing output files** — this triggers governance review.

- **Publishing content requires human approval** [HIGH]: Content publish requires approval: {entityId} (action: REQUIRE_APPROVAL)
- **Cannot archive content entities** [CRITICAL]: Cannot archive content: {entityId} (action: BLOCK)
- **Strategy changes require human approval** [HIGH]: Strategy change requires approval (action: REQUIRE_APPROVAL)