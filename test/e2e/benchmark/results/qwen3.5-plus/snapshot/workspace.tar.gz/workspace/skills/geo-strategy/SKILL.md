---
name: geo-strategy
description: 基于监测数据制定一模一策优化战略，针对每个AI模型特性定制策略
---
# GEO一模一策分析技能

## 三大AI模型特性

### 豆包（字节跳动）
- **内容偏好**：短视频/图文结合、年轻用户导向、娱乐属性强
- **优化重点**：抖音关联内容、年轻化表达、视觉化信息
- **数据格式**：JSON-LD、短视频描述优化

### 千问（阿里巴巴）
- **内容偏好**：结构化数据、商业属性、实用信息优先
- **优化重点**：高德地图关联、交易信息完整、B2B视角
- **数据格式**：Schema.org、表格化数据

### 元宝（腾讯）
- **内容偏好**：社交关系链、POI关联、微信生态
- **优化重点**：朋友圈/微信群传播、位置标签、社交证明
- **数据格式**：微信小程序数据、位置元数据

## 一模一策决策框架

针对每家门店×每个模型，根据能见度分数制定策略：

| 分数区间 | 策略类型 | 动作 |
|---------|---------|------|
| 80-100 | 巩固优势 | 维持内容更新，扩展场景覆盖 |
| 60-79 | 针对性优化 | 按模型特性定制内容 |
| 40-59 | 重点突破 | 高强度内容投放，修复信息缺口 |
| 0-39 | 基础重建 | 全面数据核查，重新提交结构化数据 |

## 输出格式
```json
{
  "storeId": "store-cs-ktv-01",
  "strategies": [
    {
      "model": "doubao",
      "score": 78,
      "strategy": "consolidate",
      "actions": ["增加抖音关联内容", "优化视觉描述"],
      "priority": "medium"
    }
  ]
}
```

## 执行任务
1. 读取当日监测数据
2. 针对每个门店×模型组合分析
3. 生成差异化优化策略
4. 输出优先级排序的行动清单

## Governance

This Skill operates under the following project governance constraints.
All write operations (`bps_update_entity`, `bps_create_task`, etc.) are automatically checked.
**Always create/update an entity via `bps_update_entity` before writing output files** — this triggers governance review.

- **Publishing content requires human approval** [HIGH]: Content publish requires approval: {entityId} (action: REQUIRE_APPROVAL)
- **Cannot archive content entities** [CRITICAL]: Cannot archive content: {entityId} (action: BLOCK)
- **Strategy changes require human approval** [HIGH]: Strategy change requires approval (action: REQUIRE_APPROVAL)