---
name: geo-content
description: 为每家门店、每个AI模型生成定制化GEO优化内容
---
# GEO内容生成技能

## 内容类型

### 1. 结构化数据文件（AI直接读取）
- store-data.json：门店基础信息Schema
- availability.json：实时房态数据
- pricing.json：价格体系数据

### 2. 模型专属内容
- **豆包**：短视频脚本、小红书风格文案、年轻化表达
- **千问**：商业问答内容、结构化描述、实用攻略
- **元宝**：朋友圈文案、微信群分享话术、位置打卡内容

### 3. 场景化内容
- "长沙五一广场附近哪里有KTV"
- "武汉楚河汉街安静喝茶的地方"
- "岳麓山附近棋牌室推荐"

## 内容生成规范

### 豆包内容风格
- 开头抓人："姐妹们！发现宝藏了！"
- emoji多用：🎤🍵🎲
- 结尾引导："评论区告诉我你还想知道啥"

### 千问内容风格
- 专业客观："该门店位于...提供...服务"
- 数据完整：地址、电话、营业时间、价格
- 实用导向：交通指南、预订方式

### 元宝内容风格
- 社交属性："朋友聚会必去"
- 位置强调：精确定位+周边地标
- 互动邀请："一起来玩吧"

## 输出路径
所有内容写入：`~/.aida/mock-publish-tmp/{platform}/`

平台目录：
- douyin/ → 豆包优化内容
- zhihu/ → 千问优化内容  
- wechat/ → 元宝优化内容

## 审批标记
生成完成后，调用bps_update_entity设置publishReady: true，触发治理审批流程。

## 执行任务
1. 读取策略分析结果
2. 为每个高优先级组合生成内容
3. 写入对应平台草稿目录
4. 提交审批请求

## Governance

This Skill operates under the following project governance constraints.
All write operations (`bps_update_entity`, `bps_create_task`, etc.) are automatically checked.
**Always create/update an entity via `bps_update_entity` before writing output files** — this triggers governance review.

- **Publishing content requires human approval** [HIGH]: Content publish requires approval: {entityId} (action: REQUIRE_APPROVAL)
- **Cannot archive content entities** [CRITICAL]: Cannot archive content: {entityId} (action: BLOCK)
- **Strategy changes require human approval** [HIGH]: Strategy change requires approval (action: REQUIRE_APPROVAL)