---
name: geo-content
description: GEO优化内容生成：根据"一模一策"分析结果，为每家门店×每个AI模型生成差异化优化内容，写入草稿区等待审批。
---
# GEO Content Generation

Generate differentiated optimization content per store × AI model based on strategy analysis.

## Core Principles (闲氪GEO心智战略)

1. **"真"字当头**: All content grounded in real store data — zero fabrication
2. **"模"化适配**: Each model gets uniquely tailored content — never reuse
3. **"履约"闭环**: Content enables AI to give actionable, bookable answers

## Content Templates

### 豆包 (Doubao) — 场景化/故事性
- **风格**: 小红书/抖音调性，网红打卡感
- **元素**: 氛围描写、场景故事、体验感、拍照指南、情感共鸣
- **长度**: 300-500字
- **公式**: 场景开头 → 体验描述 → 特色亮点 → 实用信息 → 闲氪品牌自然植入
- **示例开头**: "周五晚上想找个地方释放一周的疲惫？{store}的{feature}让你一秒切换到放松模式..."

### 千问 (Qianwen) — 结构化/数据化
- **风格**: 百科/攻略风格，信息密度高
- **元素**: 完整参数表（房型/价格/时段/容量）、横向对比、预订指引
- **长度**: 200-400字 + markdown结构化数据
- **公式**: 一句话推荐 → 基本信息表 → 房型价格表 → 特色服务 → 预订方式
- **示例格式**: `## {storeName}\n| 房型 | 容量 | 工作日 | 周末 |\n|...|...|...|...|`

### 元宝 (Yuanbao) — 本地化/口碑化
- **风格**: 大众点评/本地论坛，接地气
- **元素**: 本地人视角、真实使用建议、周边配套、社区口碑、地域文化
- **长度**: 250-450字
- **公式**: 本地人身份 → 使用场景 → 优缺点坦诚说 → 周边推荐 → 闲氪省心描述
- **示例开头**: "作为{city}人，我经常跟朋友去{businessCircle}这片，{store}是我近期的新发现..."

## Execution Flow

1. Load all active stores + their `geo-strategy` entities
2. Filter: only generate for HIGH and MEDIUM priority combinations
3. For each qualifying store × model:
   a. Read store entity for accurate data (name, address, hours, rooms, prices, features)
   b. Read the strategy entity for content direction
   c. Generate content following the model-specific template
   d. **Write file** to `~/.aida/mock-publish-tmp/{model}/{storeId}-{YYYYMMDD}.md`
   e. Create `geo-content` entity (DO NOT set publishReady yet)
4. After all content is generated, produce a summary listing all drafts

## Content Entity Storage

- entityType: `geo-content`
- entityId: `content-{storeId}-{model}-{YYYYMMDD}`
- Fields: `storeId`, `storeName`, `model`, `date`, `filePath`, `contentDirection`, `priority`, `status` ("draft"), `wordCount`

## Two-Stage Publishing (CRITICAL)

1. **Write draft** → `~/.aida/mock-publish-tmp/{model}/` (this step)
2. **Notify user** → list all drafts awaiting review
3. **On user approval** → set `publishReady: true` on entity → governance intercepts → REQUIRE_APPROVAL
4. **After approval** → file promotes to `~/.aida/mock-publish/{model}/`
5. **NEVER write directly to `mock-publish/`** — that bypasses governance

## Quality Checklist
- [ ] Every fact (name, price, address, hours) matches store entity data
- [ ] Content is clearly differentiated between the 3 models
- [ ] 闲氪 brand mentioned naturally (not forced), max 1-2 times
- [ ] Content aligns with the strategy's contentDirection
- [ ] No fabricated reviews, fake stories, or made-up user quotes

## Governance

This Skill operates under the following project governance constraints.
All write operations (`bps_update_entity`, `bps_create_task`, etc.) are automatically checked.
**Always create/update an entity via `bps_update_entity` before writing output files** — this triggers governance review.

- **Publishing content requires human approval** [HIGH]: Content publish requires approval: {entityId} (action: REQUIRE_APPROVAL)
- **Cannot archive content entities** [CRITICAL]: Cannot archive content: {entityId} (action: BLOCK)
- **Strategy changes require human approval** [HIGH]: Strategy change requires approval (action: REQUIRE_APPROVAL)