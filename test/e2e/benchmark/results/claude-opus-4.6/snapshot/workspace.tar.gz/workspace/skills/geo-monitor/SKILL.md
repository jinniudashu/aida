---
name: geo-monitor
description: GEO能见度探测：对5家合作门店×3大AI模型（豆包/千问/元宝）进行标准化能见度测试，记录出现率、推荐排名、信息准确度、品牌关联度。测试阶段使用模拟数据。
---
# GEO Visibility Monitor

Monitor store visibility across 3 major AI models: 豆包 (Doubao), 千问 (Qianwen), 元宝 (Yuanbao).
Test phase uses simulated data.

## Monitoring Dimensions

For each store × model combination, score 4 dimensions (0-100):

1. **出现率 (Appearance Rate)**: Does the AI mention this store for relevant queries?
2. **推荐排名 (Recommendation Rank)**: Position when mentioned (map 1st→100, 2nd→80, 3rd→60, 4th→40, 5th+→20)
3. **信息准确度 (Info Accuracy)**: Are name, location, price, hours correct?
4. **品牌关联度 (Brand Association)**: Does the AI associate the store with 闲氪?

**Overall Score** = appearance×0.30 + rank×0.25 + accuracy×0.25 + brand×0.20

## Standard Test Queries by Space Type

### self-service-ktv
- "{city}{businessCircle}附近有什么好的自助KTV推荐？"
- "{city}哪里有自助KTV？价格多少？"
- "想在{city}{district}附近唱歌，有什么好地方？"

### self-service-tearoom
- "{city}{businessCircle}附近有安静的茶室可以商务会谈吗？"
- "{city}哪里有自助茶室？环境怎么样？"
- "想在{city}{district}找个茶室办公，有推荐吗？"

### self-service-mahjong
- "{city}{businessCircle}附近哪里可以打麻将？"
- "{city}有什么自助棋牌室推荐？多少钱？"
- "想在{city}{district}约朋友打牌，哪里好？"

## Simulation Mode (Test Phase)

Generate realistic simulated data with these rules:

1. **Base scores** by store characteristics:
   - 核心商圈 (五一广场/楚河汉街/江汉路): base 45-60
   - 次核心 (芙蓉广场/岳麓山): base 35-50
   - 入驻时间越长 base 越高 (+2/月)

2. **Model-specific variance** (±5-15 from base):
   - 豆包: +bonus for stores with 网红/打卡/主题 features; -penalty for plain stores
   - 千问: +bonus for stores with complete structured data (address, hours, all room types); -penalty for sparse data
   - 元宝: +bonus for stores with strong local/community features; -penalty for chain-feeling stores

3. **Daily fluctuation**: ±3-8 random variance per dimension
4. **Trend**: after content optimization (published content exists), +2-5 gradual improvement per day

## Data Storage

Store each probe as entity:
- entityType: `geo-visibility`
- entityId: `vis-{storeId}-{model}-{YYYYMMDD}` (e.g. `vis-store-cs-ktv-01-doubao-20260310`)
- Fields: `storeId`, `storeName`, `model`, `date`, `appearanceRate`, `recommendRank`, `infoAccuracy`, `brandAssociation`, `overallScore`, `testQueries[]`, `simulated: true`

## Execution Steps

1. `bps_query_entities(entityType: "store")` → load all active stores
2. For each store × each model (doubao, qianwen, yuanbao):
   a. Build test queries from store data using templates above
   b. Generate simulated scores per rules above
   c. Calculate overallScore
   d. `bps_update_entity` to store the result
3. Return summary table: stores × models with scores and notable changes vs yesterday

## Governance

This Skill operates under the following project governance constraints.
All write operations (`bps_update_entity`, `bps_create_task`, etc.) are automatically checked.
**Always create/update an entity via `bps_update_entity` before writing output files** — this triggers governance review.

- **Publishing content requires human approval** [HIGH]: Content publish requires approval: {entityId} (action: REQUIRE_APPROVAL)
- **Cannot archive content entities** [CRITICAL]: Cannot archive content: {entityId} (action: BLOCK)
- **Strategy changes require human approval** [HIGH]: Strategy change requires approval (action: REQUIRE_APPROVAL)