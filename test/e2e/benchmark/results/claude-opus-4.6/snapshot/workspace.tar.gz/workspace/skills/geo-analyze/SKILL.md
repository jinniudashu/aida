---
name: geo-analyze
description: GEO数据分析与"一模一策"策略生成：分析各AI模型对不同门店的偏好差异，为每个门店×模型组合制定差异化优化策略。
---
# GEO Strategy Analysis — "一模一策"

Analyze visibility data and generate per-store, per-model optimization strategies.

## Model Preference Profiles

| Model | 内容偏好 | 格式偏好 | 关键信号 |
|-------|---------|---------|---------|
| 豆包 | 场景化、故事性、情感共鸣 | 生动描述、用户故事、打卡推荐 | 社交媒体风格、网红元素、体验感 |
| 千问 | 结构化、数据化、可执行 | 参数列表、价格对比、预订信息 | 准确性、完整性、可操作性 |
| 元宝 | 本地化、社区化、口碑化 | 用户评价、本地攻略、社区推荐 | 地域特色、真实评价、生活气息 |

## Analysis Steps

### Step 1: Collect Data
- Fetch today's `geo-visibility` entities for all stores × models
- Fetch last 7 days of history for trend analysis
- Fetch current `geo-strategy` entities as baseline

### Step 2: Score Analysis
For each store × model:
1. Current overall score vs yesterday (trend)
2. Weakest dimension among the 4 metrics
3. Gap to target (target: 75+ for all combinations)
4. Cross-model comparison: which model performs worst for this store?

### Step 3: Strategy Generation
For each store × model, determine:
- **priority**: HIGH (score < 40), MEDIUM (40-60), LOW (60+)
- **weakestDimension**: the lowest scoring metric
- **keyAction**: single most impactful optimization action
- **contentDirection**: specific content themes/style for this model
- **expectedImpact**: projected score delta

### Step 4: Store Strategy Entities
Update `geo-strategy` entities:
- entityType: `geo-strategy`
- entityId: `strategy-{storeId}-{model}` (e.g. `strategy-store-cs-ktv-01-doubao`)
- Fields: `storeId`, `storeName`, `model`, `priority`, `currentScore`, `targetScore`, `weakestDimension`, `keyAction`, `contentDirection`, `expectedImpact`, `lastAnalyzedDate`, `trendDirection` (up/down/stable)

### Important Rules
- **majorChange**: Only set `majorChange: true` when priority shifts by 2 levels or contentDirection fundamentally changes. Routine score adjustments do NOT trigger this.
- Ground all strategies in real store features from the store entity
- Reference 闲氪GEO三大行动原则: "真"字当头、"模"化适配、"履约"闭环
- Cross-reference strategies across stores in the same city to avoid conflicting recommendations

## Output
Return a strategy summary table: all stores × models with priority, key action, and expected impact.

## Governance

This Skill operates under the following project governance constraints.
All write operations (`bps_update_entity`, `bps_create_task`, etc.) are automatically checked.
**Always create/update an entity via `bps_update_entity` before writing output files** — this triggers governance review.

- **Publishing content requires human approval** [HIGH]: Content publish requires approval: {entityId} (action: REQUIRE_APPROVAL)
- **Cannot archive content entities** [CRITICAL]: Cannot archive content: {entityId} (action: BLOCK)
- **Strategy changes require human approval** [HIGH]: Strategy change requires approval (action: REQUIRE_APPROVAL)