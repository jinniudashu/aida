---
name: geo-report
description: GEO运营报告：每日运营小结（能见度概览+内容产出+明日重点）和每周深度复盘（趋势分析+模型表现+策略评估）。
---
# GEO Operations Reporting

Generate daily summaries and weekly deep-dive reviews.

## Daily Summary (每日运营小结)

### Trigger
- Daily after the monitor → analyze → content cycle completes

### Data Sources
- Today's `geo-visibility` entities (15 probes)
- Today's `geo-content` entities (drafts generated)
- Current `geo-strategy` entities (priorities)
- Yesterday's visibility data (for trend comparison)

### Report Format

```
📊 闲氪GEO日报 — {YYYY-MM-DD}

▎能见度总览
| 门店 | 豆包 | 千问 | 元宝 | 均分 | 趋势 |
|------|------|------|------|------|------|
| {storeName} | {score} | {score} | {score} | {avg} | {↑↓→} |
...
全局均分: {globalAvg} ({delta} vs 昨日)

▎今日亮点
• 📈 最大进步: {store} @ {model} +{n}分
• ⚠️ 需关注: {store} @ {model} {issue}

▎内容产出
• 生成 {n} 篇优化内容 (HIGH: {n}, MEDIUM: {n})
• 待审批: {n} 篇 → 请查看草稿区

▎明日重点
• {priority item 1}
• {priority item 2}
```

### Rules
- Keep under 25 lines — crisp and scannable
- Use emoji sparingly for visual hierarchy
- Always include actionable next steps
- Send via current chat channel to user

## Weekly Review (每周深度复盘)

### Trigger
- Every Monday 09:00

### Data Sources
- Past 7 days of `geo-visibility` entities
- Week's `geo-content` entities + their approval status
- `geo-strategy` entities (current vs week-ago)
- Published content count (files in mock-publish/)

### Report Format

```
📈 闲氪GEO周报 — {week_start} ~ {week_end}

## 一、整体表现
全局均分: {avg} (上周: {prev}, {delta})
最佳门店: {store} ({score})
最需关注: {store} ({score})

## 二、三大模型表现
### 豆包
均分 {score} ({trend}) | 偏好洞察: {insight}
### 千问
均分 {score} ({trend}) | 偏好洞察: {insight}
### 元宝
均分 {score} ({trend}) | 偏好洞察: {insight}

## 三、门店详情
(每家门店: 本周得分走势、内容产出数、关键变化)

## 四、内容效果
本周生成: {n}篇 | 审批通过: {n}篇 | 发布: {n}篇
发布前后得分对比: (如有数据)

## 五、策略评估
✅ 有效策略: {list}
🔄 需调整: {list}

## 六、下周计划
重点门店: {list}
策略方向: {list}
目标: {targets}
```

### Rules
- More detailed than daily — include data tables and trend analysis
- Highlight actionable insights over raw numbers
- Flag any strategies that need user confirmation before adjusting
- If any strategy adjustment crosses the "major change" threshold, note it explicitly

## Governance

This Skill operates under the following project governance constraints.
All write operations (`bps_update_entity`, `bps_create_task`, etc.) are automatically checked.
**Always create/update an entity via `bps_update_entity` before writing output files** — this triggers governance review.

- **Publishing content requires human approval** [HIGH]: Content publish requires approval: {entityId} (action: REQUIRE_APPROVAL)
- **Cannot archive content entities** [CRITICAL]: Cannot archive content: {entityId} (action: BLOCK)
- **Strategy changes require human approval** [HIGH]: Strategy change requires approval (action: REQUIRE_APPROVAL)